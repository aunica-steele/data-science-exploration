import dateutil
import read
df = read.load_data()


def find_hour(t):
    time = dateutil.parser.parse(t)
    hour = time.hour
    return hour

c = df['submission_time'].apply(find_hour)
d = c.value_counts()
d.sort_values(inplace = True)
print(d)
