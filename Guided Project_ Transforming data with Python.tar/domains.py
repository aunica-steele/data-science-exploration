import read

df = read.load_data()
b = df['url']

#def remove_subdomain(t):
#    y = t.split(".")
#    z = y[len(y) - 2] + "." + y[len(y) - 1]
#    return z

#b.apply(remove_subdomain)

a = df['url'].value_counts()
print(a.head(100))

#for name, row in a.items():
#    print("{0}: {1}".format(name, row))

