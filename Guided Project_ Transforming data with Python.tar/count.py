import read
import re
from collections import Counter
df = read.load_data()

#combine all headlines into one string
hl = df['headline']
h = ' '.join([str(i) for i in hl])
#print(h)
h = h.lower()
s = h.split(" ")
print(Counter(s).most_common(100))