import pandas as pd

hn_stories = pd.read_csv('hn_stories.csv')
hn_stories.columns = ['submission_time', 'upvotes', 'url', 'headline']
print(hn_stories.head())

def load_data(): 
    df = pd.read_csv("hn_stories.csv")
    df.columns = ['submission_time','upvotes','url','headline']
    return df;


